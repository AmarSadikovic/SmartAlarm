	================================================================
	*** BEFORE YOU START THE PROGRAM, PLEASE READ THIS CAREFULLY ***
	================================================================

1. Installation
==================
	1. Open the c# project and compile the project.
	2. Open up the index.html file with Chrome located in WebbApplikation folder.
	3. Input a title inside the input box to search for a specific book containing that 	title or leave it empty to search for all available books.

3. Requirements
==================
	- VisualStudio: To run the Web API
	- Chrome:	To run the Webapplikation
2. Known issues
==================
	- The first search after the API is deployed is slower.

	